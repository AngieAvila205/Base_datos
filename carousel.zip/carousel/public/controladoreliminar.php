<?php
require "../config/conexion.php";

$id = $_POST["id"];  

$sql = "DELETE FROM giros 
WHERE id= ".$id." ";

if ($dbh->query($sql)) {
    echo "Exitosamente se elimino";
} else {
    echo "Error al eliminar";
}
?>
