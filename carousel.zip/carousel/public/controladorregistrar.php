<?php
require "../config/conexion.php";

$valor = $_POST["valor"];
$documento_recibe = $_POST["documento_recibe"];  

$sql = "INSERT INTO giros (valor, documento_recibe, fecha_sys) VALUES ('$valor', '$documento_recibe', now())";
 
if ($dbh->query($sql)) {
    echo "Registro éxito";
} else {
    echo "Error";
}
?>
