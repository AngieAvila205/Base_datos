<?php
require "../config/conexion.php";
 
if (isset($_POST["nombre"]) && isset($_POST["documento"])) {
    $nombre = $_POST["nombre"];
    $documento = $_POST["documento"];
 
    $sql = "UPDATE usuario SET nombre = :nombre WHERE documento = :documento";

    try {
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':documento', $documento, PDO::PARAM_INT);
         
        if ($stmt->execute()) {
            echo "Registro actualizado con éxito.";
        } else {
            echo "Error al actualizar el registro.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Datos incompletos.";
}
?>
