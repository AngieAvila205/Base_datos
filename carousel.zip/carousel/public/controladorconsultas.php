<?php
require "../config/conexion.php";
$id = $_POST["id"];
$valor = $_POST["valor"];
$documento_recibe = $_POST["documento_recibe"];  

$sql = "SELECT id, valor, documento_recibe, fecha_sys FROM giros WHERE 1";
 
foreach($dbh-> query($sql) as $row)
{
echo "Id= ".$row ['id']." - Valor = ".$row ['valor']." - Documento = ".$row ['documento_recibe']."<br>";

}

if ($dbh->query($sql)) {
    echo "Consulta exitosa!";
} else {
    echo "Error";
}

?>



