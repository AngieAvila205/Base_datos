<?php
//$dbserver='mysql:dbname=2024_temporace;host=127.0.0.1';
$dbserver='mysql:dbname=ganagana;host=127.0.0.1';
$user = 'root';
$password = '';

try {
    $dbh = new PDO($dbserver, $user, $password);
}catch(PDOException $e){
    echo 'la conexion ha fallado: ' . $e->getMessage();
}
?>
